import React from 'react'; // importing entire library
import { Text, StyleSheet, View } from 'react-native'; // importing some piees of react-native

const AboutScreen = (props) => {
    console.log(props)
    const navigation = props.navigation

    return(
        <View>
    <titleText> About </titleText>
    <Text> Createad by Anny Gabriely Fernandes Dias</Text>
    <titleText> Version </titleText>
    <Text> FirstApp version 1.0 </Text>

    

    </View>
    )
}

export default AboutScreen