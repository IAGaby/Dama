// PART 1 - IMPORT LIBRARIES
import React from 'react'; // importing entire library
import { Text, StyleSheet, View, Button, TouchableOpacity,TextInput, } from 'react-native'; // importing some piees of react-native

// PART 2 - CREATE A COMPONENT 
// A FUNCTION THAT RETURNS SOME JSX
const ComponentsScreen = (props) => {
    const greeting = 'Now we can navigate between screens!'
    const componentAsVariable = <Text>How are you felling? </Text>
    const navigation = props.navigation

    return (
        <View>
            <Text style={styles.textStyle}>Welcome Anny to your first project</Text>
            <Text>{greeting}</Text>
            {componentAsVariable}
            
            <Button
                onPress={() => {
                    navigation.navigate('User')
                }}
                title="User Details" />
                <Button
                onPress={() => {
                    navigation.navigate('About')
                }}
                title="ABOUT" />
                
                <TouchableOpacity
                onPress={() => {
                    console.log('touchable opacity pressed')
                    navigation.navigate('List')
                }}>
            </TouchableOpacity>
        </View>
    )
}

// PART 3 CREATE A STYLESHEET TO STYLE OUR COMPONENT
const styles = StyleSheet.create({
    textStyle: {
        fontSize: 36,
        color: 'red'
    }
})

// PART 4 - EXPORT THE COMPONENT SO WE CAN USE IT ELSEWHERE IN OUR PROJECT
export default ComponentsScreen



