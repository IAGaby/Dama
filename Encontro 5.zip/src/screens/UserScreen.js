import React from 'react'; // importing entire library
import { Text, View, TouchableOpacity, } from 'react-native'; // importing some piees of react-native

const UserScreen = (props) => {
    console.log(props)
    const navigation = props.navigation

    return(
        <View>
    <titleText> Name</titleText>
    <Text> Anny Gabriely Fernandes Dias</Text>
    <titleText> Age </titleText>
    <Text> 17 anos</Text>
    <titleText> Email </titleText>
    <Text> annygabriely28@gmail.com</Text>

    <TouchableOpacity
                onPress={() => {
                    console.log('touchable opacity pressed')
                    navigation.navigate('List')
                }}>
            </TouchableOpacity>
    </View>
    )
}

export default UserScreen