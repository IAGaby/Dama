import React from 'react'
import { Text, StyleSheet, View, Button, TouchableOpacity,TextInput } from 'react-native'

const HomeScreen = (props) => {
    console.log(props)
    const navigation = props.navigation

    return (
        <View>
             <Text>User</Text>
            <TextInput
        style={styles.input}
      />
      <Text>Password</Text>
            <TextInput
        style={styles.input}
      />
            <Button
                onPress={() => {
                    console.log('button pressed')
                    navigation.navigate('Components')
                }}
                title="Logar" />
            <TouchableOpacity
                onPress={() => {
                    console.log('touchable opacity pressed')
                    navigation.navigate('List')
                }}>
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    text: {
        fontSize: 30
    },
    input: {
        height: 40,
        margin: 12,
        borderWidth: 1,
        padding: 10,
      },

})

export default HomeScreen