import React from 'react'; // importing entire library
import { Text, StyleSheet, View, } from 'react-native'; // importing some piees of react-native

const AboutScreen = (props) => {
    console.log(props)
    const navigation = props.navigation
    const Separator = () => (
        <View style={styles.separator} />
      );

    return(
        <View>
    <titleText> About </titleText>
    <Separator />
    <Text> Createad by Anny Gabriely Fernandes Dias</Text>
    <Separator />
    <titleText> Version </titleText>
    <Separator />
    <Text> FirstApp version 1.0 </Text>

    

    </View>
    )
}

const styles = StyleSheet.create({
    separator: {
        marginVertical: 8,
        borderBottomColor: '#737373',
    },
    authText: {
        fontSize: 20,
        marginTop: 50,
        fontWeight: 'bold',
        alignSelf: 'center'
    }
})
export default AboutScreen