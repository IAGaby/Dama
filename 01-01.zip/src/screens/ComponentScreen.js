// PART 1 - IMPORT LIBRARIES
import React from 'react'; // importing entire library
import { Text, StyleSheet, View, Button, TouchableOpacity,TextInput, } from 'react-native'; // importing some piees of react-native

// PART 2 - CREATE A COMPONENT 
// A FUNCTION THAT RETURNS SOME JSX
const ComponentsScreen = (props) => {
    const greeting = 'Now we can navigate between screens!'
    const componentAsVariable = <Text>How are you felling? </Text>
    const navigation = props.navigation
    const Separator = () => (
        <View style={styles.separator} />
      );

    return (
        <View>
            <Text style={styles.textStyle}>Welcome Anny to your first project</Text>
            <Separator />
            <Text>{greeting}</Text>
            {componentAsVariable}

            <Separator />
            
            <Button
                onPress={() => {
                    navigation.navigate('User')
                }}
                title="User Details" />
                 <Separator />
                <Button
                onPress={() => {
                    navigation.navigate('About')
                }}
                title="ABOUT" />

                <Separator />
                
                <TouchableOpacity
                onPress={() => {
                    console.log('touchable opacity pressed')
                    navigation.navigate('List')
                }}>
            </TouchableOpacity>
        </View>
    )
}

// PART 3 CREATE A STYLESHEET TO STYLE OUR COMPONENT
const styles = StyleSheet.create({
    textStyle: {
        fontSize: 36,
        color: 'pink'
    },
    mainView: {
        padding: 15,
        backgroundColor: 'rgb(220, 220, 220)',
        height: '100%'
    },
    authText: {
        fontSize: 20
    },
    statusText: {
        fontSize: 25,
        marginTop: 50,
        fontWeight: 'bold',
        alignSelf: 'center'
    },
    separator: {
        marginVertical: 8,
        borderBottomColor: '#737373',
    }

})

// PART 4 - EXPORT THE COMPONENT SO WE CAN USE IT ELSEWHERE IN OUR PROJECT
export default ComponentsScreen



