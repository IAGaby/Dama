import React, { useState } from "react"
import { Text, View, TextInput, Button, StyleSheet, navigation } from 'react-native'

const HomeScreen = (props) => {
    console.log(props)
    const navigation = props.navigation
    const [login, setLogin] = useState('')
    const [senha, setSenha] = useState('')
    const [statusMessage, setStatusMessage] = useState('')

    return (
        <View style={styles.mainView}>
            <Text style={styles.authText}>Login</Text>
            <TextInput
                value={login}
                onChangeText={(text) => setLogin(text)}
                style={styles.input} />
            <Text style={styles.authText}>Senha</Text>
            <TextInput
                value={senha}
                onChangeText={(text) => setSenha(text)}
                style={styles.input}
                secureTextEntry={true} />
            <Button
                title="Sign in"
                onPress={() => {
                    if (login.toLowerCase() == 'anny' &&
                        senha == '123') {
                                navigation.navigate('Components')
                    } else {
                        setStatusMessage('ERROR')
                    }
                }}
            />
            <Text style={styles.statusText}>{statusMessage}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    mainView: {
        padding: 15,
        backgroundColor: 'rgb(220, 220, 220)',
        height: '100%'
    },
    authText: {
        fontSize: 20
    },
    statusText: {
        fontSize: 25,
        marginTop: 50,
        fontWeight: 'bold',
        alignSelf: 'center'
    },
    input: {
        borderWidth: 1,
        borderRadius: 3,
        backgroundColor: 'white',
        height: 35,
        paddingHorizontal: 15,
        marginVertical: 10
    }
})

export default HomeScreen