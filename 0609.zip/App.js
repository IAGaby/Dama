import { View } from 'react-native';
// IMPORTING CUSTOM COMPONENT
import LessonComponent from './src/screens/LessonComponent';

export default function App() {
  return (
    <View>
      <LessonComponent></LessonComponent>
    </View>
  );
}

