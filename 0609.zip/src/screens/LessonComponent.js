import React from 'react'; 
import { Text, StyleSheet, View } from 'react-native'; 

const LessonComponent = () => {
    const name ='Anny Gabriely'

    return (
        <View>
           <Text style={styles.textTitulo}> Iniciando React Native</Text>
           <Text style={styles.textDetalhe}> Meu nome é {name}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    textTitulo: {
        fontSize: 45,
    },
   
    textDetalhe: {
        fontSize: 20,
    },
    
})

export default LessonComponent